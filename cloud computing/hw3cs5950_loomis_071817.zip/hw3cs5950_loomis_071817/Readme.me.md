PARKER LOOMIS
For the first part of hw3 I was able to create the bucket and IAM and do evrything except use the aws command line in order to upload and download files. I was first unable to download pip. I was eventually able to do so, but aws commands were not recognized. 
For part two. I created an instance, updated, and installed RDP and Mate. The issue lied with my user account not recognizing my password. I would change it and on the RDP side it would say login failed.
